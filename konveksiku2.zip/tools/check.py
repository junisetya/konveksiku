"""Pemeriksaan cepat tanpa server.

Memeriksa aturan validasi input, template pesan, dan konfigurasi keamanan
tanpa perlu database yang hidup.

Jalankan: python tools/check.py
"""
import os
import re
import sys
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

os.environ.setdefault("DATABASE_URL", "postgresql://u:p@localhost:5432/db")
os.environ.setdefault("OWNER_PASSWORD", "sepatu-konveksi-2026")
os.environ.setdefault("SECRET_KEY", "x" * 64)

try:
    spec = importlib.util.spec_from_file_location("appmod", ROOT / "app.py")
    app_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(app_mod)
except ModuleNotFoundError as e:
    print(f"Tidak bisa memuat app.py: {e}. "
          "Jalankan `pip install -r requirements.txt` lebih dulu.")
    sys.exit(2)

failures = []


def assert_true(cond, msg="kondisi tidak terpenuhi"):
    assert cond, msg


def expect_error(fn, *args, **kwargs):
    try:
        fn(*args, **kwargs)
    except app_mod.ValidationError:
        return
    raise AssertionError("diharapkan ValidationError, tidak Raised")


def check(name, fn):
    try:
        fn()
        print(f"  OK   {name}")
    except AssertionError as e:
        failures.append((name, str(e)))
        print(f"  FAIL {name}: {e}")
    except Exception as e:  # noqa: BLE001
        failures.append((name, repr(e)))
        print(f"  ERR  {name}: {e!r}")


def placeholders():
    out = set()
    for t in app_mod.TEMPLATES.values():
        out |= set(re.findall(r"\{(\w+)\}", t))
    return out


KNOWN_VARS = {
    "nama", "nomor", "jenis", "jumlah", "status", "estimasi", "ringkasan",
    "usaha", "total", "dibayar", "sisa", "metode", "kurir", "resi",
    "tanggal_kirim", "tiba", "diterima",
}


def routes_lengkap():
    required = {
        "/api/login", "/api/logout", "/api/state", "/api/settings",
        "/api/password", "/api/orders", "/api/orders/<ident>/action",
        "/api/photos/<ident>", "/api/backup", "/api/backup/restore",
        "/api/healthz", "/", "/manifest.webmanifest", "/sw.js",
    }
    have = {r.rule for r in app_mod.app.url_map.iter_rules()}
    hilang = required - have
    assert not hilang, f"route hilang: {sorted(hilang)}"


def header_aman(path, expect_cache):
    client = app_mod.app.test_client()
    resp = client.get(path)
    headers = resp.headers
    assert headers.get("X-Frame-Options") == "DENY", "X-Frame-Options"
    assert headers.get("X-Content-Type-Options") == "nosniff", "nosniff"
    assert "frame-ancestors 'none'" in headers.get(
        "Content-Security-Policy", ""), "CSP"
    assert headers.get("Cache-Control") == expect_cache, (
        f"Cache-Control = {headers.get('Cache-Control')!r}, "
        f"harusnya {expect_cache!r}")


def _sw_source():
    client = app_mod.app.test_client()
    return client.get("/sw.js").get_data(as_text=True)


print("validasi input")

check("teks terlalu panjang ditolak", lambda: expect_error(
    app_mod.text, "x" * 3000, 2000))
check("angka negatif ditolak", lambda: expect_error(
    app_mod.integer, "-5", 0, 10))
check("angka desimal ditolak", lambda: expect_error(
    app_mod.integer, "1.5", 0, 10))
check("angka boolean ditolak", lambda: expect_error(
    app_mod.integer, True, 0, 10))
check("tanggal format salah ditolak", lambda: expect_error(
    app_mod.date_value, "21-10-2026"))
check("nomor WA 08 -> 62", lambda: assert_true(
    app_mod.normalize_wa("081234567890") == "6281234567890"))
check("nomor WA 8 -> 62", lambda: assert_true(
    app_mod.normalize_wa("81234567890") == "6281234567890"))
check("nomor WA tidak valid ditolak", lambda: expect_error(
    app_mod.normalize_wa, "12345"))

print("struktur data")
check("prefix 2-12 huruf/angka valid", lambda: assert_true(
    re.fullmatch(r"[A-Z0-9]{2,12}", "KVK") is not None))
check("prefix terlalu pendek tidak valid", lambda: assert_true(
    re.fullmatch(r"[A-Z0-9]{2,12}", "K") is None))
check("ada 3 tahap produksi", lambda: assert_true(
    len(app_mod.STAGES) == 3))
check("default_days dalam rentang", lambda: assert_true(
    1 <= app_mod.DEFAULT_SETTINGS["default_days"] <= 365))
check("semua template pesan terisi", lambda: assert_true(
    all(v.strip() for v in app_mod.TEMPLATES.values())))
check("placeholder template dikenal", lambda: assert_true(
    placeholders() <= KNOWN_VARS, f"tak dikenal: {placeholders() - KNOWN_VARS}"))
check("variabel template lengkap", lambda: assert_true(
    placeholders() == KNOWN_VARS,
    f"kurang: {KNOWN_VARS - placeholders()}"))

print("keamanan & konfigurasi")
check("secret key cukup panjang", lambda: assert_true(
    len(app_mod.app.secret_key) >= 32))
check("cookie HttpOnly aktif", lambda: assert_true(
    app_mod.app.config["SESSION_COOKIE_HTTPONLY"] is True))
check("cookie SameSite Strict", lambda: assert_true(
    app_mod.app.config["SESSION_COOKIE_SAMESITE"] == "Strict"))
check("batas ukuran unggahan aktif", lambda: assert_true(
    app_mod.app.config["MAX_CONTENT_LENGTH"] > 0))
check("semua route API ada", routes_lengkap)
check("header keamanan di halaman", lambda: header_aman("/", "no-cache"))
check("header keamanan di API", lambda: header_aman("/api/healthz", "no-store"))
check("DATABASE_URL terbaca", lambda: assert_true(
    bool(app_mod.DATABASE_URL)))
check("halaman memuat CSP ketat", lambda: assert_true(
    "frame-ancestors 'none'" in app_mod.HTML))
check("frontend escaped output", lambda: assert_true(
    "const esc = v =>" in app_mod.HTML))
check("service worker tidak menyimpan data", lambda: assert_true(
    "caches.open" not in _sw_source(), "service worker menyimpan cache"))

print()
if failures:
    print(f"{len(failures)} pemeriksaan GAGAL")
    for n, e in failures:
        print(f"  - {n}: {e}")
    sys.exit(1)
print("semua pemeriksaan lolos")
