#!/usr/bin/env bash
# Compile-check + jalankan pemeriksaan cepat.
set -u
cd "$(dirname "$0")/.." || exit 2
python -c "import py_compile; py_compile.compile('app.py', doraise=True); py_compile.compile('tools/check.py', doraise=True); print('COMPILE_OK')" || exit 1
python tools/check.py
