"""Utilitas kecil untuk performa & SEO: sitemap, robots, pencegah tracking.

Modul ini sengaja tanpa dependensi (selain stdlib) supaya bisa dipakai
app.py maupun rofi_api_v2.py tanpa impor melingkar.
"""
import json


def _origin(base):
    return (base or "").rstrip("/")


def robots_txt(base_url):
    """robots.txt: dashboard, nota, dan tracking konsumen tidak diindeks."""
    base = _origin(base_url)
    return (
        "User-agent: *\n"
        "Allow: /\n"
        "Disallow: /api/\n"
        "Disallow: /nota/\n"
        "Disallow: /tracking/\n"
        "Disallow: /g/\n"
        "\n"
        f"Sitemap: {base}/sitemap.xml\n"
    )


def sitemap_xml(base_url, orders=None):
    """Sitemap hanya memuat halaman publik.

    Halaman nota/tracking bersifat privat (berisi data satu konsumen) dan
    sengaja tidak dimasukkan walaupun tokennya unik.
    """
    base = _origin(base_url)
    pages = [
        (f"{base}/", "1.0", "weekly"),
        (f"{base}/tracking", "0.2", "yearly"),
    ]
    parts = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
    ]
    for loc, priority, freq in pages:
        if loc.endswith("/tracking"):
            continue  # tidak ada halaman indeks tracking
        parts.append(
            f"<url><loc>{loc}</loc><changefreq>{freq}</changefreq>"
            f"<priority>{priority}</priority></url>"
        )
    parts.append("</urlset>")
    return "\n".join(parts) + "\n"


def schema_org(base_url, brand_name):
    """Structured data minimal untuk halaman login/dashboard internal."""
    data = {
        "@context": "https://schema.org",
        "@type": "Organization",
        "name": brand_name or "Rofi Jaya",
        "url": _origin(base_url) + "/",
    }
    return json.dumps(data, ensure_ascii=False)


def tracking_block_reason(user_agent, max_age=60):
    """Kembalikan alasan bila permintaan terlihat sebagai bot.

    Nota & tracking memuat data pesanan satu konsumen; tautannya rahasia
    tetapi tidak boleh bocor ke pengindeks/preview bot milik aplikasi lain.
    """
    ua = (user_agent or "").lower()
    markers = (
        "preview", "bot", "crawl", "slack", "whatsapp", "facebookexternalhit",
        "twitterbot", "telegrambot", "discord", "skype", "curl", "wget",
        "python-requests", "httpx", "headless",
    )
    for marker in markers:
        if marker in ua:
            return f"User-agent diperlakukan sebagai bot ({marker})."
    return ""
